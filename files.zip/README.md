# MiniMart Inventory (OOP Assignment 1)

## How to run
Requires Python 3.10+ (standard library only).

    python main.py

Optional tests (bonus):

    pip install pytest
    pytest

## Files
- `product.py`   - `Product` class (properties, validation, factories, counter)
- `inventory.py` - `Inventory` class (dict keyed by SKU)
- `main.py`      - demonstration script
- `test_product.py` - pytest tests

## Design decisions
- **Validation lives in property setters.** `__init__` assigns through
  `self.price = price`, so the same checks run at creation and on later
  updates. An invalid `Product` can never exist.
- **`bool` is rejected** for price and quantity, because `True` is technically
  an `int` in Python but is not a sensible price/quantity.
- **The counter increments at the end of `__init__`**, so a product that fails
  validation is not counted.
- **`Inventory` stores products in a dict by SKU** for O(1) lookup. `add`
  raises `ValueError` on a duplicate SKU; `find` returns `None` when missing;
  `remove` raises `KeyError` when missing.
- **SKU validation uses a regex** (`[A-Za-z]{3}[0-9]{3}`) with `fullmatch`.
- **Per-instance data is created in `__init__`**; only constants and the
  counter are class attributes.
